<?php
function jsontophp($file){
    return json_decode($file);//converts json array to php array.
}
function jsonelement($file,$index=0){
    $arr = jsontophp($file);//converts json array to php array.
    return $arr[$index];//returns wanted index of json file.
}
function phptojson($arr,$file){
    $string=json_encode($arr);//makes array json formatted.
    file_put_contents($file,$string);//saves json format to file.
}
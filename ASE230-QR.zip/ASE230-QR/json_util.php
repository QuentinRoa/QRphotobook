<?php
function jsontophp($file)
{
    return json_decode($file);//converts json array to php array.
}

function jsonelement($file, $index = 0)
{
    $arr = jsontophp($file);//converts json array to php array.
    return $arr[$index];//returns wanted index of json file.
}

function phptojson($arr, $file)
{
    $obj = json_encode($arr);//makes array json formatted.
    if (!file_get_contents("jsontest.json")) echo 'get not work';
    $put=file_put_contents('jsontest.json','please work');
    echo $put;

    if (!file_put_contents('jsontest.json', 'Hello')) echo 'code not work';
    else echo 'Code work';

}
<?php
require_once 'data.php';

function progress($i, $id)
{
    for ($num = 0; $num < count($id); $num++) {
        echo '<div class="py-1"><div class="progress">';
        echo '<div class="progress-bar" role="progressbar" style="width:' . $i[$num] . '%" aria-valuenow="' . $i[$num] . '" aria-valuemin="0" aria-valuemax="100">';
        echo '<div class="progress-bar-title">' . $id[$num] . '</div>';
        echo '<span class="progress-bar-number">' . $i[$num] . '%</span>';
        echo '</div></div>';
    }
}
function leapyears($year){
    $count=0;
    $newy=$year;
    $now = new DateTime();
    $currentm=$now->format('M');
    $currenty=$now->format('Y');
    for($i=0;$i<=$currenty-$year;$i++){
        if(($newy%4==0 && $newy%100!=0) || $newy%400==0){
            $count++;
        }
        $newy++;
    }
    if($currentm<=1 && ($currenty%4==0 && $currenty%100!=0) || $currenty%400==0 && $currentm<=1) $count--;
    return $count;
}
function age($year,$month,$day){
    $now = new DateTime();
    $currenty=$now->format('Y');
    $currentm=$now->format('M');
    $currentd=$now->format('D');
    $year=$currenty-$year;
    if($currentm-$month<0) $year--;
    elseif($currentm-$month==0){
        if($currentd-$day<0) $year--;
    }
    return $year;
}
function timesince($year,$month,$day){
    $days=[31,28,31,30,31,30,31,31,30,31,30,31];
    $leap=leapyears($year);
    $now = new DateTime();
    $currenty=$now->format('Y');
    $currentm=$now->format('M');
    $currentd=$now->format('D');
    $year=age($year,$month,$day);
    if($currentm-$month<0){
        $month=-$month+12+$currentm;
    }
    else $month-=$currentm;
    if ($currentd-$day<0){
        $month--;
        $day=-$day+$currentd+$days[$month]+$leap;
        while($day>$days[$currentm-1]){
            if ($currentm==2 && ($currenty%4==0 && $currenty%100!=0)|| $currenty%400==0 && $currentm==2){
                if($day<$days[1]+1){
                    break;
                }

            }
            $day=$day-1+($days[$month-1]-$days[$month]);
            $month--;
        }
    }

    return [$year,$month,$day];
}
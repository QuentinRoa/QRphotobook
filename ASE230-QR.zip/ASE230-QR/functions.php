<?php
require_once 'data.php';

function progress($i, $id)
{
    for ($num = 0; $num < count($id); $num++) {
        echo '<div class="py-1"><div class="progress">';
        echo '<div class="progress-bar" role="progressbar" style="width:' . $i[$num] . '%" aria-valuenow="' . $i[$num] . '" aria-valuemin="0" aria-valuemax="100">';
        echo '<div class="progress-bar-title">' . $id[$num] . '</div>';
        echo '<span class="progress-bar-number">' . $i[$num] . '%</span>';
        echo '</div></div>';
    }
}

function leapyears($year)
{
    $count = 0;
    $newy = $year;
    $now = new DateTime();
    $currentm = $now->format('m');
    $currenty = $now->format('Y');
    for ($i = 0; $i <= $currenty - $year; $i++) {
        if (($newy % 4 == 0 && $newy % 100 != 0) || $newy % 400 == 0) {
            $count++;
        }
        $newy++;
    }
    if ($currentm <= 1 && ($currenty % 4 == 0 && $currenty % 100 != 0) || $currenty % 400 == 0 && $currentm <= 1) $count--;
    return $count;
}

function age($year, $month, $day)
{
    $now = new DateTime();
    $currenty = $now->format('Y');
    $currentm = $now->format('m');
    $currentd = $now->format('d');
    $yearold = $currenty - $year;
    if ($currentm - $month < 0) $yearold--;
    elseif ($currentm - $month == 0) {
        if ($currentd - $day < 0) $yearold--;
    }
    return $yearold;
}

function timesince($year, $month, $day)
{
    $days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $leap = leapyears($year) ;
    $now = new DateTime();
    $currentm = $now->format('m');
    $currentd = $now->format('d');
    $day = $currentd - $day;
    $year = age($year, $month, $day);
    $year *= 365 . '  ';
    $currentm -= 2;
    for ($i = $month - 1; $i <= $currentm; $i++) {
        $year += $days[$i];
    }
    $day += $year + $leap;


    return $day;
}

function months($year, $month, $day)
{
    $leap = leapyears($year) ;
    $now = new DateTime();
    $currentm = $now->format('m');
    $currentd = $now->format('d');
    $years = age($year, $month, $day);
    $years = $years * 12;
    if ($month < $currentm) {
        $month = $currentm - $month;
    } else {
        $month = $month-($currentm - $month)+2;
    }

    $month += $years;
    if ($day+$leap > $currentd) {
        $month -= 1;
    }
    return $month;
}

function card($count, $name)
{
    for ($i = 0; $i < $count; $i++) {
        echo '<div class="col-12 col-sm-6 col-lg-3">';
        echo '<div class="single_advisor_profile wow fadeInUp" data-wow-delay="0.2s"
                 style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">';
        /*Team Thumb*/
        echo '<div class="advisor_thumb"> <a href="' . $name[$i][2] . '"><img src=' . $name[$i][11] . ' alt="" width="250"></a>';
        /*Social Info*/
        echo '<div class="social-info"><a href="' . $name[$i][2] . '"><i class="fa fa-facebook"></i></a><a href="' . $name[$i][2] . '"><i class="fa fa-twitter"></i></a><a href="' . $name[$i][2] . '"><i class="fa fa-linkedin"></i></a> </div>';
        echo '</div>';
        /*Team Details*/
        echo '<div class="single_advisor_details_info">';
        echo '<h6>' . $name[$i][0] . '</h6>';
        '<p class="designation">' . $name[$i][1] . '</p>';
        echo '<p>Year: ' . $name[$i][3] . '</p>';
        echo '<p> Date of Birth: ' . date_format(date_create_from_format('m d Y', $name[$i][13] . ' ' . $name[$i][14] . ' ' . $name[$i][15]), 'Y-m-d') . '</p>';
        echo '<p> Age: ' . age($name[$i][15], $name[$i][13], $name[$i][14]) . '</p>';
        echo '<p> Months Alive: ' . months($name[$i][15], $name[$i][13], $name[$i][14]) . '</p>';
        echo '<p> Days Alive: ' . timesince($name[$i][15], $name[$i][13], $name[$i][14]) . '</p>';

        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

}